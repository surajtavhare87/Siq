//1) Write a program in Java to read n number of values in an array and display it in reverse order
package array;
public class Reversing {

	public static void main(String[] args) {
		
		int[] arr = new int[] { 87, 88, 89, 90, 91 };
		System.out.println("Array: ");
		for (int i = 0; i < arr.length; i++) {
			System.out.print(arr[i] + " ");
		}
		System.out.println();
		System.out.println("Reverse order: ");
		for (int i = arr.length - 1; i >= 0; i--) {
			System.out.print(arr[i] + " ");
		}

	}

}
