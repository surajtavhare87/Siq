//2) Write a program in Java to find the sum of all elements of the array
package array;

public class ArraySum {

	public static void main(String[] args) {
		// Initialize array
		int[] arr = new int[] { 11, 22, 33, 44, 55 };
		int sum = 0;
		// Loop through the array to calculate sum of elements
		for (int i = 0; i < arr.length; i++) {
			sum = sum + arr[i];
		}
		System.out.println("Sum of array: " + sum);
	}
}
