//3) Write Java Program to Demonstrate Pass by Value and Pass By Reference Parameter
package functions;

class PassByValue {
	int data = 25;

	void change(int data) {
		data = data + 100;
	}

	public static void main(String args[]) {
		PassByValue op = new PassByValue();

		System.out.println("before change " + op.data);
		op.change(500);
		System.out.println("after change " + op.data);

	}
}


