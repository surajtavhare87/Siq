//Object and Class
//Create a class with data members and constructor. Pass values through constructor and assign it to variables.
//Then create an object of the class and print the value of data members.

package objectclass;

		 
		public class objectclass
		{
		    
		    String firstName;
		    String lastName;
		    int rollNo;
		    String branch;
		   
		    
		    public objectclass(String firstName, String lastName,int rollNo, String branch)
		    {
		        this.firstName = firstName;
		        this.lastName = lastName;
		        this.rollNo = rollNo;
		        this.branch = branch;
		    }
		   
		    // method 1
		    public String getfirstName()
		    {
		        return firstName;
		    }
		   
		    // method 2
		    public String getlastName()
		    {
		        return lastName;
		    }
		   
		    // method 3
		    public int getrollNo()
		    {
		        return rollNo;
		    }
		   
		    // method 4
		    public String getbranch()
		    {
		        return branch;
		    }
		   
		   
		    public static void main(String[] args)
		    {
		    
		    	objectclass details = new objectclass("Suraj","Tavhare", 87, "Extc");
		  
		      System.out.println("First Name is "+ details.getfirstName());
		      System.out.println("Last Name  is "+ details.getlastName());
		      System.out.println("RollNo "+ details.getrollNo());
		      System.out.println("Branch is "+ details.getbranch());
		        
		    }
		}

	


