//Write a class that inherits the other class. Pass the values to Super class members and print them
package inheritance;

class firstName {
	public void print_firstName() {
		System.out.println("Suraj");
	}
}

class secondName extends firstName {
	public void print_secondName() {
		System.out.println("Tavhare");
	}
}

// Driver class
public class Inheritance {
	public static void main(String[] args) {
		secondName name = new secondName();
		name.print_firstName();
		name.print_secondName();
		name.print_firstName();
	}
}
