package operator;

public class AssignmentOperator {

	public static void main(String[] args) {
		    
		    int a = 4;
		    int b = 0;
		    
		    // =+
		    b += a;
		    System.out.println("var using +=: " + b);

		    // =*
		    b *= a;
		    System.out.println("var using *=: " + b);
}
}