package operator;

public class IncrementDecrementOperator {

	 public static void main(String[] args) {
		    
	
		    int a = 45;
		    int result1, result2;

		    // original value
		    System.out.println("Value of a: " + a);

		    // increment operator
		    result1 = ++a;
		    System.out.println("After increment: " + result1);

		    // decrement operator
		    result2 = --a;
		    System.out.println("After decrement: " + result2);
		  }
		}