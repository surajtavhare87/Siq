package operator;

public class RelationalOperator {
	public static void main(String[] args) {
	 // create variables
    int a = 8, b = 15;

    // == operator
    System.out.println(a == b);  

    // != operator
    System.out.println(a != b);  

    // > operator
    System.out.println(a > b);  

    // < operator
    System.out.println(a < b);  

    // >= operator
    System.out.println(a >= b);  

    // <= operator
    System.out.println(a <= b);  
}
	}
