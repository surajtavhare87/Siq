package operator;

public class TernaryOperator {
	public static void main(String[] args) {

	    int februaryDays = 29;
	    String result;

	    // ternary operator
	    result = (februaryDays == 28) ? "Not a leap year" : "Leap year";
	    System.out.println(result);
	  }
	}