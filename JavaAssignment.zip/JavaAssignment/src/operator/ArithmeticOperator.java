package operator;

public class ArithmeticOperator {
	
	public static void main(String[] args) {
		int a = 87, b = 87;   //Instance Variable
		
		// addition 
		System.out.println("a + b = " + (a + b));

		// subtraction 
		System.out.println("a - b = " + (a - b));

		// multiplication 
		System.out.println("a * b = " + (a * b));

		// division 
		System.out.println("a / b = " + (a / b));

		// modulo 
		System.out.println("a % b = " + (a % b));

	}
}		
	


