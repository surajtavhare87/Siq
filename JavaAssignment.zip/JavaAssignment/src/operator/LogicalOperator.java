package operator;

public class LogicalOperator {
	 public static void main(String[] args) {

		    // && operator
		    System.out.println((8 > 3) && (9 > 5));  
		    System.out.println((8 > 3) && (9 < 5)); 

		    // || operator
		    System.out.println((7 < 3) || (9 > 5));  
		    System.out.println((7 < 3) || (9 < 5));  

		    // ! operator
		    System.out.println(!(6 == 4));  
		    System.out.println(!(6 > 4)); 
		  }
		}