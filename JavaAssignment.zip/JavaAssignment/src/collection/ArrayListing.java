//1) Create an Arraylist and add/remove specific element from it (input given by user). Display the Arraylist after modification.
package collection;

import java.util.ArrayList;
import java.util.Iterator;

public class ArrayListing {

	public static void main(String[] args) {
			//Creating  
			ArrayList<String> list=new ArrayList<String>();
			//Adding  
			list.add("Suraj"); 
			list.add("Ramesh");  
			list.add("Sameer");  
			list.add("Rohit");  
			//Traversing list through Iterator  
			Iterator<String> itr=list.iterator();  
			while(itr.hasNext()){  
			System.out.println(itr.next());  


	}
	}
}
