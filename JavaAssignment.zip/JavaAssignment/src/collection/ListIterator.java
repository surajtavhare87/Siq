//3) Give an example of ListIterator.
package collection;

import java.util.ArrayList;
public class ListIterator {
	public static void main(String[] args) {    
		ArrayList<String> list = new ArrayList<String>();  
		list.add("Suraj");  
		list.add("Ramesh");  
		list.add("Sahil");  
		list.add("Amit");  
		list.add("Sachin");  
		System.out.println(list);    
		java.util.ListIterator<String> iterator = list.listIterator(5);  
		System.out.println(iterator.hasNext ());    // false  
		iterator =  list.listIterator(6);    // IndexOutOfBoundsException  
		  
		}  

}
