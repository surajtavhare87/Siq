//Implement polymorphism
package polymorphism;

class Helper {

	static int mul(int a, int b) {
		return a * b;
	}

	static double mul(double a, double b) {

		return a * b;
	}
}

class Polymorphisms {
	public static void main(String[] args) {
		System.out.println(Helper.mul(3, 6));
		System.out.println(Helper.mul(6.5, 8.3));
	}
}
