//1) Write a function to accept current DATE and time and convert it to GMT format. Also print the date in different formats

package datetime;

import java.util.Date;

public class DateTime {
	public static void main(String[] args) {
		        Date current_Date = new Date();
		        // print the time and date
		        System.out.println(current_Date);
		       
		    }
}
		
