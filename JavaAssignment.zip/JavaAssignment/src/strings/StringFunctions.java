//2) Write a program which includes different operations/functions on String
package strings;

public class StringFunctions {

	public static void main(String[] args) {
	    //Length
		String firstName="suraj"; 
		String lastName="tavhare"; 
		System.out.println("length is: "+firstName.length());  
		System.out.println("length is: "+lastName.length()); 

		//Compare
		String branch="Extc"; 
		String designation="Engineer";
		System.out.println(firstName.compareTo(lastName)); 
		System.out.println(firstName.compareTo(branch)); 
		System.out.println(firstName.compareTo(designation)); 
		
		//Concat
		firstName=firstName.concat(" how are you");
		System.out.println(firstName);
		
	}

}
