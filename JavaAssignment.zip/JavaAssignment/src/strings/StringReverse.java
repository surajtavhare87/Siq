//3) Java Program to Reverse a String without using Reverse function
package strings;

public class StringReverse {

	public static void main(String[] args) {
		String Name = "Suraj Tavhare";
		String reverseName = "";

		for (int i = Name.length() - 1; i >= 0; --i) {
			reverseName += Name.charAt(i);
		}

		System.out.println(reverseName);
	}
}